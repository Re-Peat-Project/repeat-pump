"""Load stage outputs from the run GeoPackage (and the two rasters) into the project with a consistent look.

Design rules (qgis-cartography): one question per stage, the thematic layer on top and the reference layers quiet, sequential
colour for ordered magnitudes, a neutral grey for "not scored" instead of the lowest class, rasters under vectors.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from qgis.core import (QgsFillSymbol, QgsLineSymbol, QgsMarkerSymbol, QgsPalLayerSettings, QgsProject, QgsProperty, QgsRasterLayer,
                       QgsRuleBasedRenderer, QgsSingleSymbolRenderer, QgsTextBufferSettings, QgsTextFormat, QgsVectorLayer,
                       QgsVectorLayerSimpleLabeling)
from qgis.PyQt.QtGui import QColor, QFont

TEAL, AMBER, AMBER_DARK, INK, WATER = "#2B6B6B", "#E0922F", "#7A4300", "#17261F", "#3F9DAA"

# KLH map sheets (Peta Intervensi Pembasahan, KHG Mendahara-Batanghari, Sept 2026): colours sampled from the legend swatches
KLH = {"red": "#e60000", "orange": "#e69800", "sky": "#00c5ff", "green": "#4ce600", "tmat_normal": "#38a800",
       "burnt_fill": "#ffbee8", "magenta": "#e600a9", "plan_green": "#267300", "khg_blue": "#0070ff", "canal_blue": "#73b2ff"}
DROP_SVG = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 1.5C12 1.5 4.5 10.5 4.5 15.5a7.5 7.5 0 0 0 15 0'
            'C19.5 10.5 12 1.5 12 1.5Z" fill="param(fill) #00c5ff" stroke="param(outline) #000" stroke-width="param(outline-width) 1"/>'
            '<circle cx="12" cy="16" r="1.4" fill="#000000"/></svg>')


def _drop(color: str, size: float = 4.2):
    """The KLH water-table station marker: a water drop, embedded (no SVG file needed)."""
    import base64
    from qgis.core import QgsSvgMarkerSymbolLayer
    sl = QgsSvgMarkerSymbolLayer("base64:" + base64.b64encode(DROP_SVG.encode()).decode(), size)
    sl.setFillColor(QColor(color))
    sl.setStrokeColor(QColor("#000000"))
    sl.setStrokeWidth(0.3)
    return QgsMarkerSymbol([sl])


def _square_dot(color: str, size: float = 3.4, hollow: bool = False):
    """The KLH sekat marker: a coloured square with a white centre (hollow: the outline only, for blocks left out)."""
    from qgis.core import QgsSimpleMarkerSymbolLayer
    sym = QgsMarkerSymbol.createSimple({"name": "square", "color": "255,255,255,255" if hollow else color, "outline_color": color,
                                        "outline_width": "0.5" if hollow else "0.2", "size": f"{size:g}"})
    if not hollow:
        sym.appendSymbolLayer(QgsSimpleMarkerSymbolLayer.create({"name": "square", "color": "255,255,255,255", "outline_style": "no",
                                                                 "size": f"{size * 0.38:g}"}))
    return sym

# need score 0..1 in five equal steps (the score is already on a 0..1 scale), light to dark orange-red (ColorBrewer OrRd)
NEED_CLASSES = [(0.0, 0.2, "#fdd49e", "0.0 to 0.2 (lowest need)"), (0.2, 0.4, "#fdbb84", "0.2 to 0.4"), (0.4, 0.6, "#fc8d59", "0.4 to 0.6"),
                (0.6, 0.8, "#e34a33", "0.6 to 0.8"), (0.8, 1.0001, "#b30000", "0.8 to 1.0 (highest need)")]
NOT_SCORED = "#B8BEBB"

# layer -> ("line"|"point", symbol properties); names are the engine's output contract
LOOK: dict[str, tuple[str, dict]] = {
    "canals_clean": ("line", {"color": TEAL, "width": "0.5"}),
    "canal_profiles": ("point", {"name": "circle", "color": "#8D7B5E", "outline_style": "no", "size": "1.2"}),
    "network_edges": ("line", {"color": "#8A948F", "width": "0.3"}),
    "network_nodes": ("point", {"name": "circle", "color": "#8A948F", "outline_style": "no", "size": "1.6"}),
    "qa_topology_dangles": ("point", {"name": "circle", "color": "#F2A93B", "outline_color": AMBER_DARK, "outline_width": "0.4", "size": "3.2"}),
    "qa_topology_gaps": ("point", {"name": "diamond", "color": "#D8574A", "outline_color": "#6B1F18", "outline_width": "0.3", "size": "3"}),
    "sekat_existing_assessed": ("point", {"name": "square", "color": INK, "outline_color": "#FFFFFF", "outline_width": "0.3", "size": "3.2"}),
    "pump_sources": ("point", {"name": "circle", "color": WATER, "outline_color": "#0F2B26", "outline_width": "0.4", "size": "3.6"}),
    "pump_targets": ("point", {"name": "star", "color": "#2E9E7B", "outline_color": "#0F2B26", "outline_width": "0.3", "size": "4"}),
    "gates_required": ("point", {"name": "diamond", "color": "#7D4FB5", "outline_color": "#FFFFFF", "outline_width": "0.3", "size": "3.4"}),
    "qa_unreachable_targets": ("point", {"name": "cross2", "color": "#C0392B", "outline_color": "#C0392B", "outline_width": "0.8", "size": "4"}),
}


def _symbol(kind: str, props: dict):
    from qgis.core import QgsFillSymbol
    return {"line": QgsLineSymbol, "polygon": QgsFillSymbol}.get(kind, QgsMarkerSymbol).createSimple(props)


def _flow_line(color: str, width: float):
    """A cased line with arrowheads every 8 mm in its drawing direction, which is the way the water moves (sekat_reach is drawn
    from the block upstream, pump_routes from the intake to the target). On the map canvas the arrows travel along the line
    (QGIS symbol animation, ``@symbol_frame``); in a layout export they stand still."""
    from qgis.core import QgsMarkerLineSymbolLayer, QgsSimpleLineSymbolLayer, QgsSymbolLayer
    sym = QgsLineSymbol.createSimple({"color": "#ffffff", "width": f"{width + 0.6:g}", "capstyle": "round"})
    sym.appendSymbolLayer(QgsSimpleLineSymbolLayer.create({"color": color, "width": f"{width:g}", "capstyle": "round"}))
    arrows = QgsMarkerLineSymbolLayer.create({"interval": "8", "placement": "interval", "rotate": "1", "offset_along_line": "4"})
    arrows.setSubSymbol(QgsMarkerSymbol.createSimple({"name": "filled_arrowhead", "color": color, "outline_color": "#ffffff",
                                                     "outline_width": "0.25", "size": f"{2.2 + width:g}"}))
    arrows.setDataDefinedProperty(QgsSymbolLayer.Property.OffsetAlongLine, QgsProperty.fromExpression("(coalesce(@symbol_frame, 8) % 16) * 0.5"))
    sym.appendSymbolLayer(arrows)
    sym.animationSettings().setIsAnimated(True)
    sym.animationSettings().setFrameRate(10)
    return sym


def _rules(layer: QgsVectorLayer, rules: list[tuple]) -> None:
    """Rule-based renderer from ``(symbol, filter expression, label)``; the last rule may use ``"ELSE"``."""
    from .i18n import tr
    root = QgsRuleBasedRenderer.Rule(None)
    for symbol, expr, label in rules:
        root.appendChild(QgsRuleBasedRenderer.Rule(symbol, 0, 0, expr, tr(label)))       # legend labels in the wizard's language
    layer.setRenderer(QgsRuleBasedRenderer(root))


def _has(layer: QgsVectorLayer, field: str) -> bool:
    return layer.fields().indexOf(field) >= 0


def _label(layer: QgsVectorLayer, expression: str, size: float = 8.0, color: str = INK) -> None:
    fmt = QgsTextFormat()
    fmt.setFont(QFont("Segoe UI"))
    fmt.setSize(size)
    fmt.setColor(QColor(color))
    buf = QgsTextBufferSettings()
    buf.setEnabled(True)
    buf.setSize(1.0)
    buf.setColor(QColor("#FFFFFF"))
    fmt.setBuffer(buf)
    pal = QgsPalLayerSettings()
    pal.setFormat(fmt)
    pal.fieldName = expression
    pal.isExpression = True
    layer.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    layer.setLabelsEnabled(True)


def _style_need_score(layer: QgsVectorLayer) -> None:
    """Colour by need score, grey for segments that were not scored; selected targets are drawn thicker."""
    width = QgsProperty.fromExpression('CASE WHEN "selected" IS TRUE THEN 1.8 ELSE 0.7 END')
    rules = []
    for lo, hi, colour, text in NEED_CLASSES:
        sym = _symbol("line", {"color": colour, "width": "0.7", "capstyle": "round"})
        sym.setDataDefinedWidth(width)
        rules.append((sym, f'"need_score" >= {lo} AND "need_score" < {hi}', text))
    grey = _symbol("line", {"color": NOT_SCORED, "width": "0.4"})
    rules.append((grey, "ELSE", "Not scored"))
    _rules(layer, rules)


def style_layer(layer: QgsVectorLayer) -> None:
    name = layer.name()
    if name == "sekat_optimised":                     # the chosen layout stands out, the other candidates are quiet
        _rules(layer, [(_symbol("point", {"name": "square", "color": "#2E9E7B", "outline_color": "#0F2B26", "outline_width": "0.4", "size": "4.2"}),
                        '"selected_best" IS TRUE', "Chosen layout"),
                       (_symbol("point", {"name": "square", "color": "#C9C3B3", "outline_color": "#8A948F", "outline_width": "0.3", "size": "2.6"}),
                        "ELSE", "Other candidates")])
    elif name == "sekat_proposed":                    # reinforced blocks differ from standard ones
        if _has(layer, "sekat_type"):                 # KLH: Sekat Kanal Perencanaan, dark green square with a white centre
            _rules(layer, [(_square_dot(KLH["plan_green"]), '"sekat_type" = \'standard\'', "Proposed sekat, standard"),
                           (_square_dot(KLH["plan_green"], 4.4), "ELSE", "Proposed sekat, leaky or reinforced")])
        else:
            layer.setRenderer(QgsSingleSymbolRenderer(_square_dot(KLH["plan_green"])))
    elif name == "sekat_existing_assessed" and _has(layer, "snapped"):   # existing sekat not on an analysed canal are marked
        _rules(layer, [(_square_dot(KLH["magenta"], 3.0), '"snapped"', "Existing sekat"),       # KLH: Sekat Kanal Terbangun, magenta
                       (_square_dot(KLH["magenta"], 2.4, hollow=True), "ELSE", "Existing sekat, not on an analysed canal")])
    elif name == "interventions" and _has(layer, "intervention"):     # one colour per treatment, translucent over the canals
        # KLH intervention colours where the meaning matches: burnt with canals red, burnt without canals orange, not burnt with
        # canals sky blue, not burnt without canals green; the two classes KLH has no colour for take other ArcGIS palette colours
        colours = {"close_canals": "#c29ed7", "revegetate_fire": KLH["orange"], "block_water": "#0084a8", "block_wells": KLH["red"],
                   "block": KLH["sky"], "maintain": KLH["green"]}
        from qgis.core import QgsCategorizedSymbolRenderer, QgsRendererCategory
        from .i18n import tr
        from ..intervention_labels import LABELS
        rgba = lambda h, a: ",".join(str(int(h[i:i + 2], 16)) for i in (1, 3, 5)) + f",{a}"    # noqa: E731  (8-digit hex reads as #AARRGGBB)
        cats = [QgsRendererCategory(code, _symbol("polygon", {"color": rgba(col, 190), "outline_color": "110,110,110,255", "outline_width": "0.2"}), tr(LABELS[code]))
                for code, col in colours.items()]
        layer.setRenderer(QgsCategorizedSymbolRenderer("intervention", cats))
    elif name == "neraca_stations" and _has(layer, "depth_end_cm"):     # KLH water-table classes (TMAT = -depth), at the end of the dry season
        from qgis.core import QgsRuleBasedRenderer
        root = QgsRuleBasedRenderer.Rule(None)
        for expr, col, lab in (('"depth_end_cm" < 0', KLH["sky"], "AP-TMAT, Tergenang (>0 m)"),
                               ('"depth_end_cm" >= 0 AND "depth_end_cm" <= 40', KLH["tmat_normal"], "AP-TMAT, Normal (-0,4 m <= TMAT <= 0 m)"),
                               ('"depth_end_cm" > 40 AND "depth_end_cm" <= 80', KLH["orange"], "AP-TMAT, Rawan (-0,8 m <= TMAT < -0,4 m)"),
                               ('"depth_end_cm" > 80', KLH["red"], "AP-TMAT, Sangat Rawan (< -0,8 m)")):
            root.appendChild(QgsRuleBasedRenderer.Rule(_drop(col), filterExp=expr, label=lab))
        layer.setRenderer(QgsRuleBasedRenderer(root))
    elif name == "sekat_reach":                       # the canal water each kept sekat holds back, flowing from the block upstream
        layer.setRenderer(QgsSingleSymbolRenderer(_flow_line(KLH["khg_blue"], 0.7)))
    elif name == "pump_routes":                       # pumped water, from the river intake to the target
        layer.setRenderer(QgsSingleSymbolRenderer(_flow_line("#6250d6", 0.9)))
    elif name == "inputs_clipped_burn_area":          # context for the paths: where the peat has burnt
        layer.setRenderer(QgsSingleSymbolRenderer(_symbol("polygon", {"color": "255,190,232,170", "outline_color": KLH["magenta"],
                                                                       "outline_width": "0.2"})))     # KLH: Areal Terbakar, pink
    elif name == "sekat_low_benefit":                 # left out by the balance: quiet, under the proposals
        layer.setRenderer(QgsSingleSymbolRenderer(_square_dot(KLH["plan_green"], 2.4, hollow=True)))
    elif name == "sekat_scope":                       # in the plan by where it sits; the rest is greyed out (rules must not overlap: each match is drawn)
        base = {"name": "square", "outline_color": "#FFFFFF", "outline_width": "0.3", "size": "3.2"}
        _rules(layer, [(_symbol("point", {**base, "color": "#2E9E7B"}), '"planned" AND "scope" = \'target\'', "Sekat on selected canals"),
                       (_symbol("point", {**base, "color": "#7D4FB5"}), '"planned" AND "scope" = \'route\'', "Sekat on pump routes (gates)"),
                       (_symbol("point", {**base, "color": AMBER}), '"planned" AND "scope" = \'other\'', "Other sekat in the plan"),
                       (_symbol("point", {**base, "color": "#C9C3B3", "size": "2.4"}), "ELSE", "Not in the plan")])
    elif name == "pump_stations":                     # symbol area follows the power
        sym = _symbol("point", {"name": "triangle", "color": "#C0392B", "outline_color": "#FFFFFF", "outline_width": "0.3", "size": "4.4"})
        if _has(layer, "p_kw") and layer.featureCount():
            top = max((f["p_kw"] or 0) for f in layer.getFeatures()) or 1.0
            sym.setDataDefinedSize(QgsProperty.fromExpression(f'3.5 + 4.5 * sqrt(coalesce("p_kw", 0) / {top})'))
        layer.setRenderer(QgsSingleSymbolRenderer(sym))
        if _has(layer, "station_id"):
            _label(layer, '"station_id"', 8.5, "#7A1D14")
    elif name == "canal_segments":
        if _has(layer, "need_score"):
            _style_need_score(layer)
        else:
            layer.setRenderer(QgsSingleSymbolRenderer(_symbol("line", {"color": TEAL, "width": "0.6"})))
    elif name == "canals_clean":
        if _has(layer, "direction_method"):           # canals whose drainage direction could not be told apart stand out
            _rules(layer, [(_symbol("line", {"color": AMBER, "width": "0.6", "line_style": "dash"}), '"direction_method" = \'unresolved\'',
                            "Canal, flow direction unknown"),
                           (_symbol("line", {"color": KLH["canal_blue"], "width": "0.6"}), "ELSE", "Canal")])
        else:
            layer.setRenderer(QgsSingleSymbolRenderer(_symbol("line", {"color": KLH["canal_blue"], "width": "0.6"})))
        if _has(layer, "ipg"):                        # the gap-analysis result, readable on the map (IPG above 1 means enough sekat)
            _label(layer, 'CASE WHEN "ipg" IS NULL THEN \'\' ELSE \'IPG \' || format_number("ipg", 1) END', 8.0, TEAL)
    elif name in LOOK:
        kind, props = LOOK[name]
        layer.setRenderer(QgsSingleSymbolRenderer(_symbol(kind, props)))
    else:
        return
    layer.triggerRepaint()


# ----------------------------------------------------------------------------- rasters
RASTER_NAMES = {"dtm_conditioned": "dtm_conditioned", "flow_acc": "flow_acc"}


def style_raster(layer: QgsRasterLayer) -> None:
    """Quiet, translucent surfaces under the vectors: heights in greys, flow accumulation in blues clipped at the 98th percentile."""
    from qgis.core import QgsColorRampShader, QgsRasterShader, QgsSingleBandPseudoColorRenderer
    prov = layer.dataProvider()
    lo, hi = prov.cumulativeCut(1, 0.02, 0.98, layer.extent(), 250000)
    if not hi > lo:
        return
    stops = ["#F4F1EA", "#CFCABC", "#9A9684", "#5E5C50"] if layer.name() == "dtm_conditioned" else ["#EAF3F5", "#B9D9E0", "#6BB0C0", "#2B6B8F"]
    shader = QgsColorRampShader(lo, hi)
    shader.setColorRampItemList([QgsColorRampShader.ColorRampItem(lo + (hi - lo) * i / (len(stops) - 1), QColor(c)) for i, c in enumerate(stops)])
    ramp = QgsRasterShader()
    ramp.setRasterShaderFunction(shader)
    layer.setRenderer(QgsSingleBandPseudoColorRenderer(prov, 1, ramp))
    layer.renderer().setOpacity(0.75)
    layer.triggerRepaint()


# ----------------------------------------------------------------------------- layer tree
def _group(run_name: str, create: bool = True):
    root = QgsProject.instance().layerTreeRoot()
    name = f"RE-PEAT {run_name}"
    return root.findGroup(name) or (root.addGroup(name) if create else None)


# Draw order, bottom to top. Later stages add their layers last, so loading order alone would bury a route under the canals.
DRAW_ORDER = ["dtm_conditioned", "flow_acc", "interventions", "inputs_clipped_burn_area", "canals_clean", "sekat_reach", "network_edges", "canal_segments", "pump_routes", "canal_profiles", "network_nodes",
              "qa_topology_gaps", "sekat_low_benefit", "sekat_existing_assessed", "sekat_proposed", "sekat_scope", "sekat_optimised", "pump_sources", "pump_targets", "gates_required",
              "pump_stations", "qa_topology_dangles", "qa_unreachable_targets"]


def _rank(layer) -> int:
    """Draw rank, higher is drawn higher up: the fixed order above, else rasters, polygons, lines, points."""
    if layer.name() in DRAW_ORDER:
        return DRAW_ORDER.index(layer.name())
    if isinstance(layer, QgsRasterLayer):
        return -3
    try:
        from qgis.core import Qgis
        g = layer.geometryType()
        g = getattr(g, "value", g)
        return 100 + {2: 1, 1: 2, 0: 3}.get(int(g), 2)         # layers not in the fixed order sit above it
    except Exception:
        return 102


def reorder_group(group) -> None:
    """Rasters at the bottom, then polygons, lines and points, so points are never hidden under lines or surfaces."""
    nodes = [n for n in group.findLayers() if n.layer() is not None]
    order = sorted(nodes, key=lambda n: -_rank(n.layer()))              # top of the group first
    for position, node in enumerate(order):
        if group.children().index(node) != position:
            group.insertChildNode(position, node.clone())
            group.removeChildNode(node)


def remove_layers(run_name: str, names: list[str]) -> None:
    """Take outputs of stages that are about to be invalidated off the map (so stale results are not mistaken for current ones)."""
    project = QgsProject.instance()
    group = _group(run_name, create=False)
    if group is None:
        return
    for node in list(group.findLayers()):
        if node.layer() is not None and node.layer().name() in names:
            project.removeMapLayer(node.layer().id())


def remove_run_group(run_name: str) -> None:
    """Remove the run's whole group and layers (before its files are deleted: Windows will not delete an open GeoPackage)."""
    project = QgsProject.instance()
    group = _group(run_name, create=False)
    if group is None:
        return
    for node in list(group.findLayers()):
        if node.layer() is not None:
            project.removeMapLayer(node.layer().id())
    group.parent().removeChildNode(group)


def load_layers(gpkg: Path, names: list[str], run_name: str) -> list[str]:
    """Add ``names`` from the GeoPackage into a group for this run, replacing earlier copies. Returns the names loaded."""
    if not Path(gpkg).exists():
        return []
    project = QgsProject.instance()
    group = _group(run_name)
    loaded = []
    for name in names:
        for node in group.findLayers():
            if node.layer() is not None and node.layer().name() == name:
                project.removeMapLayer(node.layer().id())
        layer = QgsVectorLayer(f"{gpkg}|layername={name}", name, "ogr")
        if not layer.isValid():
            continue
        project.addMapLayer(layer, False)
        group.addLayer(layer)
        style_layer(layer)
        loaded.append(name)
    reorder_group(group)
    return loaded


def load_rasters(files: dict, run_name: str, names: Optional[list[str]] = None) -> list[str]:
    """Add the conditioned DTM and the flow accumulation (GeoTIFFs outside the GeoPackage) under the run's vector layers."""
    project = QgsProject.instance()
    group = _group(run_name)
    loaded = []
    for name in names or list(RASTER_NAMES):
        path = files.get(name)
        if not path or not Path(path).exists():
            continue
        for node in group.findLayers():
            if node.layer() is not None and node.layer().name() == name:
                project.removeMapLayer(node.layer().id())
        layer = QgsRasterLayer(str(path), name)
        if not layer.isValid():
            continue
        project.addMapLayer(layer, False)
        group.addLayer(layer)
        style_raster(layer)
        loaded.append(name)
    reorder_group(group)
    return loaded
